import { StepFunctionLambdaInput } from './lambda-helpers';
/**
 * @internal
 */
export interface TokenRetrieverInput extends StepFunctionLambdaInput {
    /** runner group of the config the orchestrator selected, empty when it has none */
    readonly group: string;
}
export declare function handler(event: TokenRetrieverInput): Promise<{
    domain: string;
    token: string;
    registrationUrl: string;
}>;
