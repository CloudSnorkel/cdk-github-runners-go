import { StepFunctionLambdaInput } from './lambda-helpers';
/**
 * @internal
 */
export interface TokenRetrieverInput extends StepFunctionLambdaInput {
    /** runner group of the config the orchestrator selected, empty when it has none */
    readonly group: string;
    /** comma separated labels the runner registers with */
    readonly labels: string;
    /** labels config.sh used to add on its own, empty when the provider turned them off. see runnerDefaultLabels() */
    readonly defaultLabels: string[];
}
export declare function handler(event: TokenRetrieverInput): Promise<{
    domain: string;
    jitConfig: string;
}>;
