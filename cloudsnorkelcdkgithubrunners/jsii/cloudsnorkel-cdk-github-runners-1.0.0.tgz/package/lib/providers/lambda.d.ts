import * as cdk from 'aws-cdk-lib';
import { aws_ec2 as ec2, aws_iam as iam, aws_lambda as lambda, aws_logs as logs, aws_stepfunctions as stepfunctions } from 'aws-cdk-lib';
import { Construct } from 'constructs';
import { BaseProvider, IRunnerProvider, IRunnerProviderStatus, RunnerConfig, RunnerProviderProps } from './common';
import { IRunnerImageBuilder, RunnerImageBuilderProps } from '../image-builders';
export interface LambdaRunnerProviderProps extends RunnerProviderProps {
    /**
     * Runner image builder used to build Docker images containing GitHub Runner and all requirements.
     *
     * The image builder must contain the {@link RunnerImageComponent.lambdaEntrypoint} component.
     *
     * The image builder determines the OS and architecture of the runner.
     *
     * @default LambdaRunnerProvider.imageBuilder()
     */
    readonly imageBuilder?: IRunnerImageBuilder;
    /**
     * GitHub Actions labels used for this provider.
     *
     * These labels are used to identify which provider should spawn a new on-demand runner. Every job sends a webhook with the labels it's looking for
     * based on runs-on. We match the labels from the webhook with the labels specified here. If all the labels specified here are present in the
     * job's labels, this provider will be chosen and spawn a new runner.
     *
     * @default ['lambda']
     */
    readonly labels?: string[];
    /**
     * GitHub Actions runner group name.
     *
     * If specified, the runner will be registered with this group name. Setting a runner group can help managing access to self-hosted runners. It
     * requires a paid GitHub account and organization level runner registration.
     *
     * The group must exist or the runner will not start.
     *
     * Users will still be able to trigger this runner with the correct labels. But the runner will only be able to run jobs from repos allowed to use the group.
     *
     * @default undefined
     */
    readonly group?: string;
    /**
     * The amount of memory, in MB, that is allocated to your Lambda function.
     * Lambda uses this value to proportionally allocate the amount of CPU
     * power. For more information, see Resource Model in the AWS Lambda
     * Developer Guide.
     *
     * @default 2048
     */
    readonly memorySize?: number;
    /**
     * The size of the function’s /tmp directory in MiB.
     *
     * @default 10 GiB
     */
    readonly ephemeralStorageSize?: cdk.Size;
    /**
     * The function execution time (in seconds) after which Lambda terminates
     * the function. Because the execution time affects cost, set this value
     * based on the function's expected execution time.
     *
     * @default Duration.minutes(15)
     */
    readonly timeout?: cdk.Duration;
    /**
     * VPC to launch the runners in.
     *
     * @default no VPC
     */
    readonly vpc?: ec2.IVpc;
    /**
     * Security groups to assign to this instance.
     *
     * @default public lambda with no security group
     */
    readonly securityGroups?: ec2.ISecurityGroup[];
    /**
     * Where to place the network interfaces within the VPC.
     *
     * @default no subnet
     */
    readonly subnetSelection?: ec2.SubnetSelection;
}
/**
 * Runner config for the Lambda family fragment.
 *
 * @internal
 */
export interface LambdaRunnerConfig extends RunnerConfig {
    readonly functionArn: string;
}
/**
 * GitHub Actions runner provider using Lambda to execute jobs.
 *
 * Creates a Docker-based function that gets executed for each job.
 *
 * Execution environments can be reused between jobs. All jobs that can run on the same function should be equally trusted. See
 * https://github.com/CloudSnorkel/cdk-github-runners#job-isolation
 *
 * This construct is not meant to be used by itself. It should be passed in the providers property for GitHubRunners.
 */
export declare class LambdaRunnerProvider extends BaseProvider implements IRunnerProvider {
    /** @internal */
    static readonly _FAMILY = "lambda";
    /**
     * The fragment that runs any Lambda provider. Reads the config {@link _runnerConfig} generated for it from
     * `$.providerParams`. Renders what LambdaInvoke used to render per provider.
     *
     * @internal
     */
    static _stateMachineFragment(scope: Construct): stepfunctions.IChainable;
    /**
     * Create new image builder that builds Lambda specific runner images.
     *
     * You can customize the OS, architecture, VPC, subnet, security groups, etc. by passing in props.
     *
     * You can add components to the image builder by calling `imageBuilder.addComponent()`.
     *
     * The default OS is Amazon Linux 2023 running on x64 architecture.
     *
     * Included components:
     *  * `RunnerImageComponent.requiredPackages()`
     *  * `RunnerImageComponent.runnerUser()`
     *  * `RunnerImageComponent.git()`
     *  * `RunnerImageComponent.githubCli()`
     *  * `RunnerImageComponent.awsCli()`
     *  * `RunnerImageComponent.githubRunner()`
     *  * `RunnerImageComponent.lambdaEntrypoint()`
     */
    static imageBuilder(scope: Construct, id: string, props?: RunnerImageBuilderProps): import("../image-builders").IConfigurableRunnerImageBuilder;
    /**
     * The function hosting the GitHub runner.
     */
    readonly function: lambda.Function;
    /**
     * Labels associated with this provider.
     */
    readonly labels: string[];
    /**
     * Grant principal used to add permissions to the runner role.
     */
    readonly grantPrincipal: iam.IPrincipal;
    /**
     * Docker image loaded with GitHub Actions Runner and its prerequisites. The image is built by an image builder and is specific to Lambda.
     */
    private readonly image;
    /**
     * Log group where provided runners will save their logs.
     *
     * Note that this is not the job log, but the runner itself. It will not contain output from the GitHub Action but only metadata on its execution.
     */
    readonly logGroup: logs.ILogGroup;
    private readonly group?;
    private readonly defaultLabels;
    private readonly vpc?;
    private readonly securityGroups?;
    constructor(scope: Construct, id: string, props?: LambdaRunnerProviderProps);
    /**
     * The network connections associated with this resource.
     */
    get connections(): ec2.Connections;
    private addImageUpdater;
    /**
     * Config for the shared Lambda fragment.
     *
     * @internal
     */
    _runnerConfig(): LambdaRunnerConfig;
    /**
     * @internal
     */
    _grantStateMachine(stateMachineRole: iam.IGrantable): void;
    /**
     * @internal
     */
    _status(statusFunctionRole: iam.IGrantable): IRunnerProviderStatus;
}
