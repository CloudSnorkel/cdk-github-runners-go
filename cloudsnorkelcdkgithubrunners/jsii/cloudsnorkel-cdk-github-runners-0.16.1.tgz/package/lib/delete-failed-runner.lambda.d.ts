import { StepFunctionLambdaInput } from './lambda-helpers';
/**
 * Outcome of the clean-up, stored in `$.delete` by the step function so the execution history says what happened.
 *
 * We don't fail the execution ourselves. The original error that got us here is re-raised by a separate `Rethrow Error`
 * state, so a red `Delete Failed Runner` state always means the clean-up itself had a problem.
 */
interface DeleteFailedRunnerResult {
    /**
     * Was a runner still registered on GitHub Actions when we looked for it?
     */
    readonly runnerFound: boolean;
    /**
     * Did we delete the runner? Always false when no runner was found, as there is nothing to delete.
     */
    readonly runnerDeleted: boolean;
}
export declare function handler(event: StepFunctionLambdaInput): Promise<DeleteFailedRunnerResult>;
export {};
