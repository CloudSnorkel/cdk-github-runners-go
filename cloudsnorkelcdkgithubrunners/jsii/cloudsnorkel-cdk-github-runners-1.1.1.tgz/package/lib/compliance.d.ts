import { aws_kms as kms } from 'aws-cdk-lib';
import { IConstruct } from 'constructs';
/**
 * Keys used by {@link Compliance.encrypt}. Each type of resource uses its own key if set, or `key` otherwise. Types with neither are left as they are.
 */
export interface ComplianceEncryptionOptions {
    /**
     * Key for every type of resource that doesn't have its own key below.
     *
     * @default only types with their own key are encrypted
     */
    readonly key?: kms.IKey;
    /**
     * Key for CloudWatch log groups, including runner logs.
     *
     * @default `key`
     */
    readonly logs?: kms.IKey;
    /**
     * Key for Secrets Manager secrets holding GitHub credentials.
     *
     * @default `key`
     */
    readonly secrets?: kms.IKey;
    /**
     * Key for the Step Functions state machine, SQS queues, SNS topics and the DynamoDB table used to manage runners.
     *
     * @default `key`
     */
    readonly messages?: kms.IKey;
    /**
     * Key for ECR repositories holding runner images, and for AMIs built for EC2 runners. EC2 runner volumes are encrypted with the key of their AMI.
     *
     * Adding a key to an existing repository replaces it. The deployment waits for the image to be rebuilt in the new repository before runners use it.
     *
     * @default `key`
     */
    readonly images?: kms.IKey;
    /**
     * Key for runner storage: EBS volumes of ECS instances, Fargate ephemeral storage, CodeBuild build output, and buckets used to build images.
     *
     * ECS clusters and capacity providers you pass in are not changed.
     *
     * @default `key`
     */
    readonly storage?: kms.IKey;
}
/**
 * Reserved concurrency for Lambda functions used by runners.
 */
export interface ComplianceLambdaConcurrencyOptions {
    /**
     * How many jobs you expect to start at the same time. Functions called for every job, like the webhook handler, can run this many at once.
     * If more jobs start at once, they wait a bit longer for a runner.
     *
     * Status, setup, warm runner and deployment helper functions are limited to 5.
     *
     * @default 20
     */
    readonly maxJobStarts?: number;
    /**
     * How many jobs each Lambda runner provider can run at the same time.
     *
     * @default 20
     */
    readonly maxLambdaJobs?: number;
}
/**
 * Settings that compliance frameworks like HIPAA, PCI DSS, and NIST 800-53 ask for, applied to everything this library creates in a scope.
 *
 * The scope can be an app, a stage, a stack, or a single construct like a runner provider. Settings of the closest scope win, so you can set a key
 * for a whole stack and a stricter one for a single provider. Resources you create yourself are not changed.
 *
 * Once anything uses {@link Compliance}, synth warns about runner resources in the same stage that no scope covers. Like other aspects, an app
 * scope doesn't reach into nested stages, so call {@link Compliance.of} on those stages too.
 *
 * ```typescript
 * Compliance.of(stack).encrypt({ key });
 * Compliance.of(gpuProvider).encrypt({ storage: gpuKey });
 * Compliance.of(stack).limitLambdaConcurrency();
 * ```
 */
export declare class Compliance {
    private readonly scope;
    /**
     * Compliance settings for everything this library creates in the given scope.
     */
    static of(scope: IConstruct): Compliance;
    private constructor();
    /**
     * Encrypt data at rest with your own KMS keys.
     *
     * Keys created in the same app get the key policy they need. For imported keys, a warning lists the statements to add to the key policy.
     */
    encrypt(options: ComplianceEncryptionOptions): void;
    /**
     * Set reserved concurrency on Lambda functions.
     *
     * This reserves 5 x `maxJobStarts` for functions called on every job, `maxLambdaJobs` for every Lambda runner provider, and 5 for every other
     * function. With the defaults, that's about 120 for a simple deployment and 190 for one using every feature. Reserved concurrency comes out of
     * your account limit, and the account must keep 100 unreserved.
     */
    limitLambdaConcurrency(options?: ComplianceLambdaConcurrencyOptions): void;
    private settings;
}
