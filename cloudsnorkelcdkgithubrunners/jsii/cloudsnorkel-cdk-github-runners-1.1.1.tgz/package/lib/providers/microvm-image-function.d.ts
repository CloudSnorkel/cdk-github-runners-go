import * as lambda from 'aws-cdk-lib/aws-lambda';
import { Construct } from 'constructs';
/**
 * Props for MicrovmImageFunction
 */
export interface MicrovmImageFunctionProps extends lambda.FunctionOptions {
    /**
     * The Lambda runtime to use.
     * @default - Latest Node.js runtime available in the deployment region
     */
    readonly runtime?: lambda.Runtime;
}
/**
 * An AWS Lambda function which executes src/providers/microvm-image.
 */
export declare class MicrovmImageFunction extends lambda.Function {
    constructor(scope: Construct, id: string, props?: MicrovmImageFunctionProps);
}
