import { aws_codebuild as codebuild, aws_ec2 as ec2, aws_iam as iam, aws_logs as logs, aws_stepfunctions as stepfunctions, Duration } from 'aws-cdk-lib';
import { Construct } from 'constructs';
import { BaseProvider, IParameterizedRunnerProvider, IRunnerProvider, IRunnerProviderStatus, RunnerConfig, RunnerProviderProps } from './common';
import { IRunnerImageBuilder, RunnerImageBuilderProps } from '../image-builders';
export interface CodeBuildRunnerProviderProps extends RunnerProviderProps {
    /**
     * Runner image builder used to build Docker images containing GitHub Runner and all requirements.
     *
     * The image builder must contain the {@link RunnerImageComponent.docker} component unless `dockerInDocker` is set to false.
     *
     * The image builder determines the OS and architecture of the runner.
     *
     * @default CodeBuildRunnerProvider.imageBuilder()
     */
    readonly imageBuilder?: IRunnerImageBuilder;
    /**
     * GitHub Actions labels used for this provider.
     *
     * These labels are used to identify which provider should spawn a new on-demand runner. Every job sends a webhook with the labels it's looking for
     * based on runs-on. We match the labels from the webhook with the labels specified here. If all the labels specified here are present in the
     * job's labels, this provider will be chosen and spawn a new runner.
     *
     * @default ['codebuild']
     */
    readonly labels?: string[];
    /**
     * GitHub Actions runner group name.
     *
     * If specified, the runner will be registered with this group name. Setting a runner group can help managing access to self-hosted runners. It
     * requires a paid GitHub account and organization level runner registration.
     *
     * The group must exist or the runner will not start.
     *
     * Users will still be able to trigger this runner with the correct labels. But the runner will only be able to run jobs from repos allowed to use the group.
     *
     * @default undefined
     */
    readonly group?: string;
    /**
     * VPC to launch the runners in.
     *
     * @default no VPC
     */
    readonly vpc?: ec2.IVpc;
    /**
     * Security groups to assign to this instance.
     *
     * @default a new security group, if {@link CodeBuildRunnerProviderProps.vpc} is used
     */
    readonly securityGroups?: ec2.ISecurityGroup[];
    /**
     * Where to place the network interfaces within the VPC.
     *
     * @default no subnet
     */
    readonly subnetSelection?: ec2.SubnetSelection;
    /**
     * The type of compute to use for this build.
     * See the {@link ComputeType} enum for the possible values.
     *
     * The compute type determines CPU, memory, and disk space:
     * - SMALL: 2 vCPU, 3 GB RAM, 64 GB disk
     * - MEDIUM: 4 vCPU, 7 GB RAM, 128 GB disk
     * - LARGE: 8 vCPU, 15 GB RAM, 128 GB disk
     * - X2_LARGE: 72 vCPU, 145 GB RAM, 256 GB disk (Linux) or 824 GB disk (Windows)
     *
     * Use a larger compute type when you need more disk space for building larger Docker images.
     *
     * For more details, see https://docs.aws.amazon.com/codebuild/latest/userguide/build-env-ref-compute-types.html#environment.types
     *
     * @default {@link ComputeType#SMALL}
     */
    readonly computeType?: codebuild.ComputeType;
    /**
     * The number of minutes after which AWS CodeBuild stops the build if it's
     * not complete. For valid values, see the timeoutInMinutes field in the AWS
     * CodeBuild User Guide.
     *
     * @default Duration.hours(1)
     */
    readonly timeout?: Duration;
    /**
     * Support building and running Docker images by enabling Docker-in-Docker (dind) and the required CodeBuild privileged mode. Disabling this can
     * speed up provisioning of CodeBuild runners. If you don't intend on running or building Docker images, disable this for faster start-up times.
     *
     * @default true
     */
    readonly dockerInDocker?: boolean;
    /**
     * Use GPU compute for builds. When enabled, the default compute type is BUILD_GENERAL1_SMALL (4 vCPU, 16 GB RAM, 1 NVIDIA A10G GPU).
     *
     * You can override the compute type using the `computeType` property (for example, to use BUILD_GENERAL1_LARGE for more resources),
     * subject to the supported GPU compute types.
     *
     * When using GPU compute, ensure your runner image includes any required GPU libraries (for example, CUDA)
     * either by using a base image that has them preinstalled (such as an appropriate nvidia/cuda image) or by
     * adding image components that install them. The default image builder does not automatically switch to a
     * CUDA-enabled base image when GPU is enabled.
     *
     * GPU compute is only available for Linux x64 images. Not supported on Windows or ARM.
     *
     * @default false
     */
    readonly gpu?: boolean;
}
/**
 * Runner config for the CodeBuild family fragment.
 *
 * @internal
 */
interface CodeBuildRunnerConfig extends RunnerConfig {
    readonly projectName: string;
}
/**
 * GitHub Actions runner provider using CodeBuild to execute jobs.
 *
 * Creates a project that gets started for each job.
 *
 * This construct is not meant to be used by itself. It should be passed in the {@link GitHubRunnersProps.providers} property for {@link GitHubRunners}.
 */
export declare class CodeBuildRunnerProvider extends BaseProvider implements IRunnerProvider, IParameterizedRunnerProvider {
    /** @internal */
    static readonly _FAMILY = "codebuild";
    /**
     * The fragment that runs any CodeBuild provider. Reads the config {@link _runnerConfig} generated for it from
     * `$.providerParams`. Renders what CodeBuildStartBuild used to render per provider.
     *
     * @internal
     */
    static _stateMachineFragment(scope: Construct): stepfunctions.IChainable;
    /**
     * Create new image builder that builds CodeBuild specific runner images.
     *
     * You can customize the OS, architecture, VPC, subnet, security groups, etc. by passing in props.
     *
     * You can add components to the image builder by calling {@link IConfigurableRunnerImageBuilder.addComponent}.
     *
     * The default OS is Ubuntu running on x64 architecture.
     *
     * Included components:
     *  * {@link RunnerImageComponent.requiredPackages}
     *  * {@link RunnerImageComponent.runnerUser}
     *  * {@link RunnerImageComponent.git}
     *  * {@link RunnerImageComponent.githubCli}
     *  * {@link RunnerImageComponent.awsCli}
     *  * {@link RunnerImageComponent.docker}
     *  * {@link RunnerImageComponent.githubRunner}
     */
    static imageBuilder(scope: Construct, id: string, props?: RunnerImageBuilderProps): import("../image-builders").IConfigurableRunnerImageBuilder;
    /**
     * CodeBuild project hosting the runner.
     */
    readonly project: codebuild.Project;
    /**
     * Labels associated with this provider.
     */
    readonly labels: string[];
    /**
     * Grant principal used to add permissions to the runner role.
     */
    readonly grantPrincipal: iam.IPrincipal;
    /**
     * Docker image loaded with GitHub Actions Runner and its prerequisites. The image is built by an image builder and is specific to CodeBuild.
     */
    private readonly image;
    /**
     * Log group where provided runners will save their logs.
     *
     * Note that this is not the job log, but the runner itself. It will not contain output from the GitHub Action but only metadata on its execution.
     */
    readonly logGroup: logs.ILogGroup;
    private readonly group?;
    private readonly vpc?;
    private readonly securityGroups?;
    private readonly dind;
    private readonly defaultLabels;
    constructor(scope: Construct, id: string, props?: CodeBuildRunnerProviderProps);
    /**
     * Config for the shared CodeBuild fragment.
     *
     * @internal
     */
    _runnerConfig(): CodeBuildRunnerConfig;
    /**
     * @internal
     */
    _grantStateMachine(stateMachineRole: iam.IGrantable): void;
    /**
     * @internal
     */
    _status(statusFunctionRole: iam.IGrantable): IRunnerProviderStatus;
    /**
     * The network connections associated with this resource.
     */
    get connections(): ec2.Connections;
}
export {};
