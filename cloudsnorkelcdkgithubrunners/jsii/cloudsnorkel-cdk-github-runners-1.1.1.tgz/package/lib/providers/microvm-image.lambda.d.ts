import { UpdateMicrovmImageRequest } from '@aws-sdk/client-lambda-microvms';
import * as AWSLambda from 'aws-lambda';
/**
 * Event sent by the ECR push rule when the runner image has been rebuilt, and by the stack rule when CloudFormation is
 * done deploying. Lambda doesn't follow the image tag, so we have to tell it to build a new image version out of the
 * image that was pushed.
 */
interface RebuildInput {
    readonly image: UpdateMicrovmImageRequest;
    readonly stackId: string;
    readonly repositoryName: string;
    readonly imageTag: string;
}
/**
 * Resource properties of the custom resource that uploads a zip with a Dockerfile to S3. The Dockerfile is used by Lambda to build the
 * MicroVM image.
 *
 * @internal
 */
export interface SetupInput {
    readonly ServiceToken: string;
    readonly Bucket: string;
    readonly Key: string;
    readonly Dockerfile: string;
}
export declare function handler(event: AWSLambda.CloudFormationCustomResourceEvent | RebuildInput): Promise<void>;
export {};
