import * as lambda from 'aws-cdk-lib/aws-lambda';
import { Construct } from 'constructs';
/**
 * Props for DeleteFailedRunnerFunction
 */
export interface DeleteFailedRunnerFunctionProps extends lambda.FunctionOptions {
}
/**
 * An AWS Lambda function which executes src/delete-failed-runner.
 */
export declare class DeleteFailedRunnerFunction extends lambda.Function {
    constructor(scope: Construct, id: string, props?: DeleteFailedRunnerFunctionProps);
}
