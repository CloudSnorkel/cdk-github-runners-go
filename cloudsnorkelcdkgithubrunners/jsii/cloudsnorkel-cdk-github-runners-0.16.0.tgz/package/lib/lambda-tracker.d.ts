import { OrchestratorInput } from './lambda-common';
/**
 * Default time-to-live for job records in DynamoDB. GitHub jobs can wait up to 24 hours to get a runner. This adds some margin.
 *
 * If we accidentally provision a runner, that's expensive. Keeping a small record in DynamoDB for a few days is cheaper.
 *
 * @internal
 */
export declare const DEFAULT_TRACKER_TTL_SECONDS: number;
/**
 * A runner told us it picked up a job. Sent by the runners themselves, from a job started hook, and read out of
 * their logs. Also sent by the webhook handler for workflow_job.in_progress events.
 *
 * GitHub never tells a runner which job it's running, so this carries the workflow run instead. Combined with the
 * runner name it's enough to ask GitHub for the job id.
 *
 * @internal
 */
export interface RunnerReportMessage {
    readonly kind: 'report';
    readonly runnerName: string;
    readonly repo: string;
    readonly workflowId: number;
    readonly jobId?: number;
}
/**
 * Remember that we started a runner for this job. Written before the step function starts, so it's always there by
 * the time GitHub could possibly hand the runner a job.
 *
 * The extra fields are for whoever is reading the table during an incident. Only the key is ever used. TTL is used for cleanup.
 *
 * @internal
 */
export declare function recordControlledJob(input: OrchestratorInput): Promise<void>;
/**
 * Is this a job we started a runner for?
 *
 * @internal
 */
export declare function isControlledJob(jobId: number): Promise<boolean>;
