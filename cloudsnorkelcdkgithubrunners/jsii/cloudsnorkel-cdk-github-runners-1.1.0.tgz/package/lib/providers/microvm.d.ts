import * as cdk from 'aws-cdk-lib';
import { aws_ec2 as ec2, aws_iam as iam, aws_logs as logs, aws_stepfunctions as stepfunctions } from 'aws-cdk-lib';
import { Construct } from 'constructs';
import { BaseProvider, IParameterizedRunnerProvider, IRunnerProvider, IRunnerProviderStatus, RunnerConfig, RunnerProviderProps } from './common';
import { IRunnerImageBuilder, RunnerImageBuilderProps } from '../image-builders';
/**
 * @experimental
 */
export interface MicroVmRunnerProviderProps extends RunnerProviderProps {
    /**
     * Runner image builder used to build Docker images containing GitHub Runner and all requirements.
     *
     * The image builder must contain the {@link RunnerImageComponent.microVmEntrypoint} component.
     *
     * @default MicroVmRunnerProvider.imageBuilder()
     */
    readonly imageBuilder?: IRunnerImageBuilder;
    /**
     * GitHub Actions labels used for this provider.
     *
     * These labels are used to identify which provider should spawn a new on-demand runner. Every job sends a webhook with the labels it's looking for
     * based on runs-on. We match the labels from the webhook with the labels specified here. If all the labels specified here are present in the
     * job's labels, this provider will be chosen and spawn a new runner.
     *
     * @default ['microvm']
     */
    readonly labels?: string[];
    /**
     * GitHub Actions runner group name.
     *
     * If specified, the runner will be registered with this group name. Setting a runner group can help managing access to self-hosted runners. It
     * requires a paid GitHub account and organization level runner registration.
     *
     * The group must exist or the runner will not start.
     *
     * Users will still be able to trigger this runner with the correct labels. But the runner will only be able to run jobs from repos allowed to use the group.
     *
     * @default undefined
     */
    readonly group?: string;
    /**
     * Memory given to the MicroVM. CPU is allocated proportionally, about one vCPU for every 2 GiB.
     *
     * @default 4 GiB (and therefore 2 vCPU)
     */
    readonly memorySize?: cdk.Size;
    /**
     * Time after which the MicroVM is terminated, whether the job is done or not. Must be 8 hours or less.
     *
     * @default Duration.hours(1)
     */
    readonly timeout?: cdk.Duration;
    /**
     * VPC to send the runner's outbound traffic through. The network interfaces never get a public IP, so the subnets
     * need a NAT gateway (or VPC endpoints) to reach GitHub, ECR and CloudWatch. Public subnets won't work.
     *
     * @default no VPC, runners get public internet access
     */
    readonly vpc?: ec2.IVpc;
    /**
     * Where to place the network interfaces within the VPC.
     *
     * @default default subnets of the VPC
     */
    readonly subnetSelection?: ec2.SubnetSelection;
    /**
     * Security groups to assign to the outbound traffic.
     *
     * @default a new security group, if VPC is used
     */
    readonly securityGroups?: ec2.ISecurityGroup[];
}
/**
 * Runner config for the MicroVM family fragment.
 *
 * @internal
 */
export interface MicroVmRunnerConfig extends RunnerConfig {
    readonly imageArn: string;
    readonly executionRoleArn: string;
    readonly logGroupName: string;
    readonly egressNetworkConnectors: string[];
    readonly ingressNetworkConnectors: string[];
    readonly maxDurationSeconds: number;
    readonly jitConfigParameterPrefix: string;
}
/**
 * GitHub Actions runner provider using Lambda MicroVMs to execute jobs.
 *
 * MicroVMs sit between Lambda and EC2. They boot from a snapshot in about a second, they have a writable disk and a
 * real kernel, and they can run for up to eight hours.
 *
 * This construct is not meant to be used by itself. It should be passed in the providers property for GitHubRunners.
 *
 * This provider is experimental and may change in the future.
 *
 * @experimental
 */
export declare class MicroVmRunnerProvider extends BaseProvider implements IRunnerProvider, IParameterizedRunnerProvider {
    /** @internal */
    static readonly _FAMILY = "microvm";
    /**
     * The fragment that runs any MicroVM provider. Reads the config {@link _runnerConfig} generated for it from
     * `$.providerParams`.
     *
     * The runner reports back with the task token we put in the run hook payload, and then exits its hook server which
     * ends the MicroVM. Similar to what EC2 provider does.
     *
     * The run hook payload is limited to 4KB and a JIT config alone is about that big. We put it in an SSM parameter with
     * a random name, which the runner reads and deletes. It expires on its own in case the runner never gets to it.
     *
     * @internal
     */
    static _stateMachineFragment(scope: Construct): stepfunctions.IChainable;
    /**
     * Create new image builder that builds MicroVM specific runner images.
     *
     * You can customize the OS, architecture, VPC, subnet, security groups, etc. by passing in props.
     *
     * You can add components to the image builder by calling `imageBuilder.addComponent()`.
     *
     * The default OS is Amazon Linux 2023 running on x64 architecture.
     *
     * The default base image is Lambda's own, which is the only one guaranteed to survive being snapshotted. Among
     * other things it carries an AWS-patched OpenSSL, so don't change it unless you know your image is snapshot
     * compatible.
     *
     * Included components:
     *  * `RunnerImageComponent.requiredPackages()`
     *  * `RunnerImageComponent.runnerUser()`
     *  * `RunnerImageComponent.git()`
     *  * `RunnerImageComponent.githubCli()`
     *  * `RunnerImageComponent.awsCli()`
     *  * `RunnerImageComponent.githubRunner()`
     *  * `RunnerImageComponent.microVmEntrypoint()`
     */
    static imageBuilder(scope: Construct, id: string, props?: RunnerImageBuilderProps): import("../image-builders").IConfigurableRunnerImageBuilder;
    /**
     * Labels associated with this provider.
     */
    readonly labels: string[];
    /**
     * Grant principal used to add permissions to the runner role.
     */
    readonly grantPrincipal: iam.IPrincipal;
    /**
     * Log group where provided runners will save their logs.
     *
     * Note that this is not the job log, but the runner itself. It will not contain output from the GitHub Action but only metadata on its execution.
     */
    readonly logGroup: logs.ILogGroup;
    private readonly image;
    private readonly runnerImage;
    private readonly role;
    private readonly group?;
    private readonly defaultLabels;
    private readonly timeout;
    private readonly vpc?;
    private readonly securityGroups?;
    private readonly egressNetworkConnectors;
    private readonly jitConfigParameterPrefix;
    private readonly jitConfigParameterArns;
    private readonly ingressNetworkConnectors;
    constructor(scope: Construct, id: string, props?: MicroVmRunnerProviderProps);
    /**
     * The network connections associated with this resource.
     *
     * These security groups only apply to outbound traffic through the VPC. Inbound access to the MicroVM goes through
     * Lambda's endpoint with an auth token, and not through the VPC.
     */
    get connections(): ec2.Connections;
    /**
     * MicroVM images are built by Lambda out of a zipped Dockerfile in S3, and not out of a container image. The runner
     * image repository is only known at deploy time, so a custom resource writes the Dockerfile for us.
     *
     * All MicroVM providers in the stack share one bucket, each with its own key.
     */
    private codeArtifact;
    /**
     * Lambda resolves the image tag when the MicroVM image is built, and then sticks to that image. Whenever the runner
     * image is rebuilt, we have to explicitly tell Lambda to build a new MicroVM image version out of it.
     */
    private addImageUpdater;
    private imageFunction;
    /**
     * Config for the shared MicroVM fragment.
     *
     * @internal
     */
    _runnerConfig(): MicroVmRunnerConfig;
    /**
     * @internal
     */
    _grantStateMachine(stateMachineRole: iam.IGrantable): void;
    /**
     * @internal
     */
    _status(statusFunctionRole: iam.IGrantable): IRunnerProviderStatus;
}
